<?php

namespace App\Controller;

use App\Entity\Enfermero;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/nurse', name: 'nurse_')]
class NurseController extends AbstractController
{
    private EntityManagerInterface $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    #[Route('/index', name: 'index', methods: ['GET'])]
    public function index(): JsonResponse
    {
        $nurses = $this->entityManager->getRepository(Enfermero::class)->findAll();
        $return_nurses = [];

        foreach ($nurses as $nurse) {
            $return_nurses[] = [
                'email' => $nurse->getCorreo(),
                'name' => $nurse->getNombre(),
            ];
        }

        return new JsonResponse($return_nurses);
    }

    #[Route('/name/{str_name}', name: 'list_name', methods: ['GET'])]
    public function findByName(string $str_name): JsonResponse
    {
        $nurse = $this->entityManager->getRepository(Enfermero::class)->findOneBy(['nombre' => $str_name]);

        if ($nurse) {
            return new JsonResponse(['email' => $nurse->getCorreo(), 'name' => $nurse->getNombre()]);
        }

        return new JsonResponse(['error' => 'Nurse not found'], 404);
    }

    #[Route('/login', name: 'login', methods: ['POST'])]
    public function login(Request $request): JsonResponse
    {
        $email = $request->get('email');
        $password = $request->get('password');

        if ($email === null || $password === null) {
            return new JsonResponse(['error' => 'Email and password must be provided'], 400);
        }

        $nurse = $this->entityManager->getRepository(Enfermero::class)->findOneBy(['correo' => $email]);

        if ($nurse && $nurse->getPassword() === $password) { 
            return new JsonResponse(['success' => true], 200);
        }

        return new JsonResponse(['success' => false, 'error' => 'Invalid credentials'], 401);
    }
}
