<?php

namespace App\Entity;

use App\Repository\EnfermeroRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: EnfermeroRepository::class)]
class Enfermero
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private string $nombre;

    #[ORM\Column(length: 255, unique: true)]
    private string $correo;

    #[ORM\Column(length: 255)]
    private string $password; // Cambié 'password' a 'password'

    public function __construct(string $nombre = '', string $correo = '', string $password = '') // Constructor opcional
    {
        $this->nombre = $nombre;
        $this->correo = $correo;
        $this->password = $password;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNombre(): string
    {
        return $this->nombre;
    }

    public function setNombre(string $nombre): self
    {
        $this->nombre = $nombre;
        return $this;
    }

    public function getCorreo(): string
    {
        return $this->correo;
    }

    public function setCorreo(string $correo): self
    {
        $this->correo = $correo;
        return $this;
    }

    public function getPassword(): string 
    {
        return $this->password;
    }

    public function setPassword(string $password): self
    {
        $this->password = $password;
        return $this;
    }

}
