<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/nurse/index' => [[['_route' => 'nurse_index', '_controller' => 'App\\Controller\\NurseController::index'], null, ['GET' => 0], null, false, false, null]],
        '/nurse/login' => [[['_route' => 'nurse_login', '_controller' => 'App\\Controller\\NurseController::login'], null, ['POST' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/nurse/name/([^/]++)(*:62)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        62 => [
            [['_route' => 'nurse_list_name', '_controller' => 'App\\Controller\\NurseController::findByName'], ['str_name'], ['GET' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
